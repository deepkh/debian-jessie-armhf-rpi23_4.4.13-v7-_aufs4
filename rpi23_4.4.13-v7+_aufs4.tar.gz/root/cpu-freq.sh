#!/bin/bash
while [ 1 ]
do
        A=`cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq`
        A1=`cat /sys/devices/system/cpu/cpu1/cpufreq/scaling_cur_freq`
        A2=`cat /sys/devices/system/cpu/cpu2/cpufreq/scaling_cur_freq`
        A3=`cat /sys/devices/system/cpu/cpu3/cpufreq/scaling_cur_freq`
        B=`/opt/vc/bin/vcgencmd measure_temp`
        echo $A $A1 $A2 $A3 $B
        sleep 1
done

