sysbench --num-threads=8 --test=cpu --cpu-max-prime=10000000000 run

